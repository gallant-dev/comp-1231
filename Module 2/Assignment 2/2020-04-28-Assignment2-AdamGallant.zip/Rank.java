//Rank.java
//MATH 1231 - Assignment 2
//Adam Gallant T00632271
//
//Represents a priority rank for tasks.
public class Rank {
    int value;
    String description;

    //Constructor
    public Rank (int integer, String string){
        value = integer;
        description = string;
    }
}